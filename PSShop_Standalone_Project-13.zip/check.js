
const KEY='ps_manager_v1';
const today=()=>new Date().toLocaleDateString('en-CA');
const defaultState=()=>({settings:{shopName:'محل العرض',rate:1000,half:6,sound:'yes'},devices:Array.from({length:6},(_,i)=>({id:i+1,name:'بلايستيشن '+(i+1),match:i===0,session:null,queue:[]})),foosballTables:[],records:[],nextId:7,nextTableId:1});
let state=load(),alerted=new Set(),audioCtx=null;
if(!Array.isArray(state.foosballTables))state.foosballTables=[];
if(!Number(state.nextTableId))state.nextTableId=Math.max(0,...state.foosballTables.map(t=>Number(t.id)||0))+1;
if(!Array.isArray(state.devices))state.devices=[];
state.devices.forEach(d=>{if(!Array.isArray(d.queue))d.queue=[]});
state.foosballTables.forEach(t=>{if(!Array.isArray(t.queue))t.queue=[]});
if(state.settings && state.settings.shopName==='محل البلايستيشن'){state.settings.shopName='محل العرض';try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
function normalizeDigits(value){return String(value??'').replace(/[٠-٩۰-۹]/g,ch=>String(ch.charCodeAt(0)>=0x06f0&&ch.charCodeAt(0)<=0x06f9?ch.charCodeAt(0)-0x06f0:ch.charCodeAt(0)-0x0660)).replace(/[٫٬]/g,'.').replace(/،/g,'.').trim()}
document.addEventListener('input',function(e){const el=e.target;if(el&&el.matches('input[data-numeric="true"]')){const pos=el.selectionStart;const old=el.value;const next=normalizeDigits(old);if(next!==old){el.value=next;try{el.setSelectionRange(pos,pos)}catch(err){}}}});
function load(){try{return JSON.parse(localStorage.getItem(KEY))||defaultState()}catch(e){return defaultState()}}
function save(){localStorage.setItem(KEY,JSON.stringify(state));}
function money(n){return Number(n||0).toLocaleString('en-US')+' ر.ي';}
function fmt(ms){let s=Math.max(0,Math.ceil(ms/1000)),m=Math.floor(s/60),r=s%60;return String(m).padStart(2,'0')+':'+String(r).padStart(2,'0')}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function currentDateRecords(){return state.records.filter(r=>r.date===today())}
function incomeFor(date){return state.records.filter(r=>r.date===date).reduce((s,r)=>s+Number(r.amount||0),0)}
function updateStats(){const all=[...state.devices,...state.foosballTables];document.getElementById('todayIncome').textContent=money(incomeFor(today()));document.getElementById('busyCount').textContent=all.filter(d=>d.session).length;document.getElementById('freeCount').textContent=all.filter(d=>!d.session).length;document.getElementById('sessionsCount').textContent=currentDateRecords().length}
function queueEntry(q){return typeof q==='string'?{name:q,minutes:30,playersCount:2}:q||{name:'عميل',minutes:30,playersCount:2}}
function renderQueueHtml(resource,kind){return resource.queue.map((raw,i)=>{const q=queueEntry(raw);return `<div class="queue-item"><span>${i+1}. ${esc(q.name)} • ${Number(q.minutes)||30} دقيقة${kind==='table'?' • '+(Number(q.playersCount)||2)+' لاعبين':''}</span><button onclick="removeQueue('${kind}',${resource.id},${i})">حذف</button></div>`}).join('')||'<div class="note">لا يوجد عملاء في الانتظار</div>'}
function renderDevices(){
 const root=document.getElementById('devices');
 if(!state.devices.length){root.innerHTML='<div class="panel empty">لا توجد أجهزة. اضغط «إضافة جهاز» للبدء.</div>';updateStats();return}
 root.innerHTML=state.devices.map(d=>{
  const s=d.session,remain=s?(s.endAt-Date.now()):0,expired=s&&remain<=0,match=s&&s.type==='match';
  const status=!s?'متاح':expired?'انتهى الوقت':match?(s.half===1?'الشوط الأول':'الشوط الثاني'):'مشغول';
  return `<article class="device ${expired?'expired':''}" id="dev-${d.id}">
  <div class="devhead"><h3>${esc(d.name)}</h3><span class="badge ${s?'busy':'free'}">${status}</span></div>
  <div class="timer" data-timer="device-${d.id}">${s?fmt(remain):'00:00'}</div>
  <div class="sub">${s?(match?`مباراة • الشوط ${s.half} من 2 • ${s.half===1?'يتبقى للشوط الأول':'يتبقى للشوط الثاني'}`:'وقت الجلسة المتبقي'):'الجهاز جاهز لاستقبال عميل'}</div>
  <div class="who">${s?'👤 '+esc(s.customer||'عميل بدون اسم')+(s.type==='match'?' • مباراة':''):''}</div>
  <div class="actions">${!s?`<button class="good" onclick="startSession(${d.id},'normal')">بدء جلسة</button><button class="primary" onclick="startSession(${d.id},'match')">بدء مباراة</button>`:`<button class="warn" onclick="finishSession(${d.id},'manual')">إنهاء وتسجيل</button><button onclick="addTime(${d.id},5)">+٥ دقائق</button><button onclick="addTime(${d.id},10)">+١٠ دقائق</button><button onclick="silenceDevice(${d.id})">إسكات</button>`}
  <button onclick="toggleMatch(${d.id})">${d.match?'إلغاء وضع المباريات':'تفعيل وضع المباريات'}</button><button class="danger" onclick="renameDevice(${d.id})">تعديل الاسم</button><button class="danger" onclick="removeDevice(${d.id})">حذف الجهاز</button></div>
  <div class="queue"><div class="queue-title">قائمة الانتظار (${d.queue.length})</div>
  ${renderQueueHtml(d,'device')}
  <div class="inlineform"><input id="q-${d.id}" placeholder="اسم العميل المنتظر" maxlength="60"><button onclick="addQueue(${d.id})">＋ انتظار</button></div></div></article>`;
 }).join('');
 updateStats();
}
function renderFoosballTables(){
 const root=document.getElementById('foosballTables');if(!state.foosballTables.length){root.innerHTML='<div class="panel empty">لم تُضف أي طاولة بعد. اضغط «إضافة طاولة فرفيرة» للبدء.</div>';updateStats();return}
 root.innerHTML=state.foosballTables.map(t=>{const s=t.session,remain=s?s.endAt-Date.now():0,expired=s&&remain<=0;return `<article class="table-card ${expired?'expired':''}" id="table-${t.id}">
 <div class="devhead"><h3>⚽ ${esc(t.name)}</h3><span class="badge ${s?'busy':'free'}">${!s?'متاحة':expired?'انتهى الوقت':'مشغولة'}</span></div>
 <div class="timer" data-timer="table-${t.id}">${s?fmt(remain):'00:00'}</div>
 <div class="sub">${s?`فرفيرة • ${s.playersCount} لاعبين • الوقت المتبقي`:'الطاولة جاهزة للعب'}</div>
 <div class="who">${s?'👥 '+esc(s.customerGroup||((s.players||[]).join(' / '))):''}</div>
 <div class="actions">${!s?`<button class="good" onclick="startFoosball(${t.id})">بدء لعب</button>`:`<button class="warn" onclick="finishFoosball(${t.id})">إنهاء وتسجيل</button><button onclick="addFoosballTime(${t.id},5)">+٥ دقائق</button><button onclick="addFoosballTime(${t.id},10)">+١٠ دقائق</button>`}<button class="danger" onclick="renameFoosballTable(${t.id})">تعديل الاسم</button><button class="danger" onclick="removeFoosballTable(${t.id})">حذف الطاولة</button></div>
 <div class="queue"><div class="queue-title">قائمة انتظار الطاولة (${t.queue.length})</div>${renderQueueHtml(t,'table')}<div class="inlineform"><input id="tq-${t.id}" placeholder="اسم المجموعة المنتظرة" maxlength="60"><button onclick="addFoosballQueue(${t.id})">＋ انتظار</button></div></div>
 </article>`}).join('');updateStats();
}
function startSession(id,type){
 const d=state.devices.find(x=>x.id===id);if(!d||d.session)return;
 const customer=prompt('اسم العميل (يمكن تركه فارغاً):','');if(customer===null)return;
 let mins;
 if(type==='match') mins=Number(state.settings.half)||6;
 else {const v=prompt('مدة الجلسة بالدقائق (تقبل الأرقام العربية والإنجليزية):', '30');if(v===null)return;const text=normalizeDigits(v);if(!/^[0-9]+(?:\.[0-9]+)?$/.test(text)){alert('أدخل مدة صحيحة، مثل ٣٠ أو 30.');return}mins=Number(text);if(!Number.isFinite(mins)||mins<=0){alert('أدخل مدة صحيحة أكبر من صفر.');return}}
 const startAt=Date.now();d.session={customer:customer.trim()||'عميل بدون اسم',type,startedAt:startAt,endAt:startAt+mins*60000,initialMinutes:mins,half:1,firstHalfMinutes:mins,priceRate:Number(state.settings.rate)||0};
 alerted.delete('device-'+id);save();renderDevices();
}
function recordFinishedSession(resource,session,displayName,kind,reason='manual'){
 const mins=Math.max(1,Math.ceil((Date.now()-session.startedAt)/60000));const suggested=Math.round(mins*(session.priceRate||0)/60);
 state.records.push({date:today(),time:new Date().toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'}),device:displayName,customer:session.customer||((session.players||[]).join(' / '))||'عميل بدون اسم',type:kind,minutes:mins,amount:suggested,reason});
}
function startQueuedDeviceSession(d,next){const q=queueEntry(next),now=Date.now(),mins=Math.max(1,Number(q.minutes)||30);d.session={customer:q.name,type:'normal',startedAt:now,endAt:now+mins*60000,initialMinutes:mins,half:1,priceRate:Number(state.settings.rate)||0,autoQueueSession:true};alerted.delete('device-'+d.id)}
function finishSession(id,reason='manual'){
 const d=state.devices.find(x=>x.id===id);if(!d||!d.session)return;
 const s=d.session;let mins=Math.max(1,Math.ceil((Date.now()-s.startedAt)/60000));const suggested=Math.round(mins*(s.priceRate||0)/60);
 const amt=prompt('المبلغ المستحق للجلسة (تقبل الأرقام العربية والإنجليزية):',String(suggested));if(amt===null)return;
 const amount=Number(normalizeDigits(amt));if(!Number.isFinite(amount)||amount<0){alert('أدخل مبلغاً صحيحاً.');return}
 state.records.push({date:today(),time:new Date().toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'}),device:d.name,customer:s.customer,type:s.type==='match'?'مباراة':'جلسة عادية',minutes:mins,amount,reason});
 d.session=null;alerted.delete('device-'+id);alerted.delete(id);
 if(d.queue.length){const next=d.queue.shift();startQueuedDeviceSession(d,next);document.getElementById('alertbar').textContent='✅ انتهت الجلسة وبدأ العميل المنتظر تلقائيًا على '+d.name+'.';document.getElementById('alertbar').classList.add('show')}
 save();renderDevices();renderReports();
}
function addTime(id,mins){const d=state.devices.find(x=>x.id===id);if(!d?.session)return;d.session.endAt=Math.max(Date.now(),d.session.endAt)+mins*60000;alerted.delete(id);alerted.delete('device-'+id);save();renderDevices()}
function addQueue(id){const d=state.devices.find(x=>x.id===id),el=document.getElementById('q-'+id),v=el.value.trim();if(!v)return;const dur=prompt('مدة لعب العميل المنتظر بالدقائق:','30');if(dur===null)return;const mins=Number(normalizeDigits(dur));if(!Number.isFinite(mins)||mins<=0){alert('أدخل مدة صحيحة أكبر من صفر.');return}d.queue.push({name:v,minutes:mins});save();renderDevices()}
function removeQueue(kind,id,i){const collection=kind==='table'?state.foosballTables:state.devices;const d=collection.find(x=>x.id===id);if(!d)return;d.queue.splice(i,1);save();kind==='table'?renderFoosballTables():renderDevices()}
function toggleMatch(id){const d=state.devices.find(x=>x.id===id);d.match=!d.match;save();renderDevices()}
function renameDevice(id){const d=state.devices.find(x=>x.id===id),v=prompt('اسم الجهاز الجديد:',d.name);if(v&&v.trim()){d.name=v.trim();save();renderDevices()}}
function removeDevice(id){const d=state.devices.find(x=>x.id===id);if(!d)return;if(!confirm('حذف '+d.name+'؟ سيتم فقد قائمة انتظاره والجلسة الحالية.'))return;state.devices=state.devices.filter(x=>x.id!==id);save();renderDevices()}
function openAddDevice(){const name=prompt('اسم الجهاز الجديد:','بلايستيشن '+state.nextId);if(!name||!name.trim())return;state.devices.push({id:state.nextId++,name:name.trim(),match:false,session:null,queue:[]});save();renderDevices()}
function addFoosballTable(){const name=prompt('اسم طاولة الفرفيرة:','فرفيرة '+state.nextTableId);if(!name||!name.trim())return;state.foosballTables.push({id:state.nextTableId++,name:name.trim(),session:null,queue:[]});save();renderFoosballTables()}
function startFoosball(id,queued=null){const t=state.foosballTables.find(x=>x.id===id);if(!t||t.session)return;let playersCount,players=[],minutes,group='';if(queued){const q=queueEntry(queued);playersCount=Number(q.playersCount)===4?4:2;minutes=Math.max(1,Number(q.minutes)||30);group=q.name;players=Array.isArray(q.players)&&q.players.length?q.players:[q.name];}else{const count=prompt('عدد اللاعبين؟ اكتب ٢ أو ٤','2');if(count===null)return;playersCount=Number(normalizeDigits(count));if(![2,4].includes(playersCount)){alert('عدد اللاعبين يجب أن يكون ٢ أو ٤.');return}const names=prompt('أسماء اللاعبين مفصولة بفاصلة (يمكن تركها فارغة):','');if(names===null)return;players=names.split(/[,،]/).map(x=>x.trim()).filter(Boolean);if(!players.length)players=Array.from({length:playersCount},(_,i)=>'لاعب '+(i+1));if(players.length!==playersCount){alert('أدخل '+playersCount+' أسماء، أو اترك الخانة فارغة.');return}const dur=prompt('مدة اللعب بالدقائق:','30');if(dur===null)return;minutes=Number(normalizeDigits(dur));if(!Number.isFinite(minutes)||minutes<=0){alert('أدخل مدة صحيحة أكبر من صفر.');return}}
 const now=Date.now();t.session={customer:group||players.join(' / '),customerGroup:group,players,playersCount,type:'foosball',startedAt:now,endAt:now+minutes*60000,initialMinutes:minutes,priceRate:Number(state.settings.rate)||0};alerted.delete('table-'+id);save();renderFoosballTables()}
function startQueuedFoosball(t,next){const q=queueEntry(next);startFoosball(t.id,q)}
function finishFoosball(id,automatic=false){const t=state.foosballTables.find(x=>x.id===id);if(!t||!t.session)return;const s=t.session,mins=Math.max(1,Math.ceil((Date.now()-s.startedAt)/60000)),suggested=Math.round(mins*(s.priceRate||0)/60);let amount=suggested;if(!automatic){const amt=prompt('المبلغ المستحق للعب الفرفيرة:',String(suggested));if(amt===null)return;amount=Number(normalizeDigits(amt));if(!Number.isFinite(amount)||amount<0){alert('أدخل مبلغًا صحيحًا.');return}}
 state.records.push({date:today(),time:new Date().toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'}),device:t.name,customer:s.customer||'مجموعة لاعبين',type:'فرفيرة ('+s.playersCount+' لاعبين)',minutes:mins,amount,reason:automatic?'انتهاء تلقائي مع قائمة انتظار':'manual'});t.session=null;alerted.delete('table-'+id);if(t.queue.length){const next=t.queue.shift();startQueuedFoosball(t,next);document.getElementById('alertbar').textContent='✅ انتهى اللعب وبدأت المجموعة المنتظرة تلقائيًا على '+t.name+'.';document.getElementById('alertbar').classList.add('show')}save();renderFoosballTables();renderReports()}
function addFoosballQueue(id){const t=state.foosballTables.find(x=>x.id===id),el=document.getElementById('tq-'+id),name=el.value.trim();if(!name)return;const count=prompt('عدد اللاعبين للمجموعة المنتظرة؟ اكتب ٢ أو ٤','2');if(count===null)return;const playersCount=Number(normalizeDigits(count));if(![2,4].includes(playersCount)){alert('عدد اللاعبين يجب أن يكون ٢ أو ٤.');return}const dur=prompt('مدة اللعب للمجموعة المنتظرة بالدقائق:','30');if(dur===null)return;const minutes=Number(normalizeDigits(dur));if(!Number.isFinite(minutes)||minutes<=0){alert('أدخل مدة صحيحة أكبر من صفر.');return}t.queue.push({name,minutes,playersCount});save();renderFoosballTables()}
function addFoosballTime(id,mins){const t=state.foosballTables.find(x=>x.id===id);if(!t?.session)return;t.session.endAt=Math.max(Date.now(),t.session.endAt)+mins*60000;alerted.delete('table-'+id);save();renderFoosballTables()}
function renameFoosballTable(id){const t=state.foosballTables.find(x=>x.id===id),name=prompt('اسم الطاولة الجديد:',t.name);if(name&&name.trim()){t.name=name.trim();save();renderFoosballTables()}}
function removeFoosballTable(id){const t=state.foosballTables.find(x=>x.id===id);if(!t)return;if(!confirm('حذف '+t.name+'؟ ستُحذف جلسة الطاولة وقائمة الانتظار الحالية.'))return;state.foosballTables=state.foosballTables.filter(x=>x.id!==id);save();renderFoosballTables();renderDevices()}
function processAutoQueue(resource,kind){if(!resource.session||!resource.queue.length)return false;const s=resource.session;const mins=Math.max(1,Math.ceil((Date.now()-s.startedAt)/60000));const amount=Math.round(mins*(s.priceRate||0)/60);const name=kind==='table'?resource.name:resource.name;state.records.push({date:today(),time:new Date().toLocaleTimeString('ar',{hour:'2-digit',minute:'2-digit'}),device:name,customer:s.customer||'عميل بدون اسم',type:kind==='table'?'فرفيرة ('+(s.playersCount||2)+' لاعبين)':s.type==='match'?'مباراة':'جلسة عادية',minutes:mins,amount,reason:'انتهاء تلقائي مع قائمة انتظار'});resource.session=null;const next=resource.queue.shift();if(kind==='table')startQueuedFoosball(resource,next);else startQueuedDeviceSession(resource,next);return true}
let alarmTimer=null;
function beep(){if(state.settings.sound==='no')return;try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();[0,0.28,0.56].forEach(t=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='square';o.connect(g);g.connect(audioCtx.destination);o.frequency.value=1100;g.gain.setValueAtTime(.55,audioCtx.currentTime+t);g.gain.setValueAtTime(.55,audioCtx.currentTime+t+.16);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+t+.24);o.start(audioCtx.currentTime+t);o.stop(audioCtx.currentTime+t+.25)});if(navigator.vibrate)navigator.vibrate([500,180,500,180,700])}catch(e){}}
function startAlarm(){if(alarmTimer!==null)return;beep();alarmTimer=setInterval(beep,1800)}
function stopAlarm(){if(alarmTimer!==null){clearInterval(alarmTimer);alarmTimer=null}if(navigator.vibrate)navigator.vibrate(0)}
function testSound(){beep();const b=document.getElementById('alertbar');b.textContent='🔔 هذا تنبيه تجريبي للصوت والواجهة.';b.classList.add('show');setTimeout(()=>{b.classList.remove('show');b.textContent='⏰ انتهى الوقت! راجع الأجهزة المنتهية.'},2500)}
function silenceDevice(id){stopAlarm();alerted.delete(id);alerted.delete('device-'+id);const d=state.devices.find(x=>x.id===id);if(d?.session&&d.session.endAt<Date.now())d.session.endAt=Date.now()+1000;document.getElementById('alertbar').classList.remove('show')}
function silenceAll(){stopAlarm();alerted.clear();document.getElementById('alertbar').classList.remove('show')}
function tick(){
 let changed=false,expiredNames=[];
 const resources=[...state.devices.map(d=>({item:d,kind:'device'})),...state.foosballTables.map(t=>({item:t,kind:'table'}))];
 resources.forEach(({item:d,kind})=>{if(!d.session)return;let s=d.session,remain=s.endAt-Date.now(),timerKey=(kind==='table'?'table-':'device-')+d.id;
  if(remain<=0&&kind==='device'&&s.type==='match'&&s.half===1){s.half=2;s.endAt=Date.now()+(Number(state.settings.half)||6)*60000;alerted.delete(timerKey);beep();changed=true}
  else if(remain<=0&&d.queue.length){if(processAutoQueue(d,kind)){expiredNames.push(d.name+' (بدأ المنتظر تلقائيًا)');alerted.delete(timerKey);changed=true}}
  else if(remain<=0&&!alerted.has(timerKey)){alerted.add(timerKey);expiredNames.push(d.name);startAlarm()}
  const el=document.querySelector(`[data-timer="${timerKey}"]`);if(el)el.textContent=fmt(d.session?d.session.endAt-Date.now():0);
  const card=document.getElementById((kind==='table'?'table-':'dev-')+d.id);if(card)card.classList.toggle('expired',!!d.session&&d.session.endAt<=Date.now());
 });
 if(expiredNames.length){const b=document.getElementById('alertbar');b.textContent='⏰ انتهى الوقت: '+expiredNames.join('، ')+'. إذا كانت هناك قائمة انتظار يبدأ التالي تلقائيًا.';b.classList.add('show')}
 if(changed){save();renderDevices();renderFoosballTables();renderReports()}updateStats();
}
function saveSettings(){state.settings.shopName=document.getElementById('shopName').value.trim()||'محل العرض';state.settings.rate=Math.max(0,Number(normalizeDigits(document.getElementById('hourRate').value))||0);state.settings.half=Math.max(1,Number(normalizeDigits(document.getElementById('halfLength').value))||6);state.settings.sound=document.getElementById('soundOn').value;save();alert('تم حفظ الإعدادات');renderDevices()}
function renderSettings(){document.getElementById('shopName').value=state.settings.shopName||'محل العرض';document.getElementById('hourRate').value=state.settings.rate;document.getElementById('halfLength').value=state.settings.half;document.getElementById('soundOn').value=state.settings.sound}
function renderReports(){const date=document.getElementById('reportDate').value||today();const rs=state.records.filter(r=>r.date===date);document.getElementById('reportTotal').value=money(rs.reduce((a,r)=>a+Number(r.amount||0),0));document.getElementById('reportCount').value=rs.length;document.getElementById('records').innerHTML=rs.length?rs.slice().reverse().map(r=>`<tr><td>${esc(r.time)}</td><td>${esc(r.device)}</td><td>${esc(r.customer)}</td><td>${esc(r.type)}</td><td>${r.minutes} دقيقة</td><td>${money(r.amount)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">لا توجد سجلات لهذا التاريخ.</td></tr>';updateStats()}
function exportCSV(){const date=document.getElementById('reportDate').value||today(),rs=state.records.filter(r=>r.date===date);const rows=[['التاريخ','الوقت','الجهاز','العميل','النوع','المدة بالدقائق','المبلغ'],...rs.map(r=>[r.date,r.time,r.device,r.customer,r.type,r.minutes,r.amount])];const csv='\\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\\r\\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download='تقرير-البلايستيشن-'+date+'.csv';a.click();URL.revokeObjectURL(a.href)}
function clearTodayConfirm(){const date=document.getElementById('reportDate').value||today();if(!confirm('هل تريد حذف جميع سجلات يوم '+date+'؟ لا يمكن التراجع.'))return;state.records=state.records.filter(r=>r.date!==date);save();renderReports()}
function downloadBackup(){const content=JSON.stringify(state,null,2),filename='نسخة-احتياطية-البلايستيشن.json';if(window.AndroidBridge&&typeof window.AndroidBridge.saveBackup==='function'){window.AndroidBridge.saveBackup(content,filename);return}const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type:'application/json'}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function restoreBackupFile(input){const file=input.files&&input.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const imported=JSON.parse(String(reader.result||''));if(!imported||typeof imported!=='object'||!imported.settings||!Array.isArray(imported.devices)||!Array.isArray(imported.records)){throw new Error('invalid')}if(!confirm('سيتم استبدال بيانات البرنامج الحالية بالنسخة الاحتياطية المحددة. هل تريد المتابعة؟')){input.value='';return}state={settings:{shopName:String(imported.settings.shopName||'محل العرض'),rate:Math.max(0,Number(imported.settings.rate)||0),half:Math.max(1,Number(imported.settings.half)||6),sound:imported.settings.sound==='no'?'no':'yes'},devices:imported.devices,nextId:Math.max(Number(imported.nextId)||1,1),foosballTables:Array.isArray(imported.foosballTables)?imported.foosballTables:[],nextTableId:Math.max(Number(imported.nextTableId)||1,1),records:imported.records};state.devices.forEach(d=>{if(!Array.isArray(d.queue))d.queue=[]});state.foosballTables.forEach(t=>{if(!Array.isArray(t.queue))t.queue=[]});save();alert('تمت استعادة النسخة الاحتياطية بنجاح.');renderSettings();renderDevices();renderFoosballTables();renderReports();input.value=''}catch(e){alert('تعذر استعادة الملف. تأكد أنه ملف JSON احتياطي صادر من برنامج محل العرض.');input.value=''}};reader.onerror=()=>{alert('تعذر قراءة الملف.');input.value=''};reader.readAsText(file)}
function resetApp(){if(!confirm('سيتم حذف جميع بيانات البرنامج من هذا المتصفح. هل أنت متأكد؟'))return;state=defaultState();save();renderSettings();renderDevices();renderFoosballTables();renderReports()}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));['dashboard','foosball','reports','settings'].forEach(id=>document.getElementById(id).classList.toggle('hidden',id!==b.dataset.tab));if(b.dataset.tab==='reports'){document.getElementById('reportDate').value=today();renderReports()}if(b.dataset.tab==='settings')renderSettings();if(b.dataset.tab==='foosball')renderFoosballTables()}));
renderSettings();renderDevices();renderFoosballTables();document.getElementById('reportDate').value=today();renderReports();setInterval(tick,250);

