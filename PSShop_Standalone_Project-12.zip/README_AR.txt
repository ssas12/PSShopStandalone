مشروع Android يضم برنامج إدارة محل البلايستيشن داخل التطبيق. يُبنى APK عبر GitHub Actions. بعد نجاح البناء نزّل artifact باسم PSShopStandalone-APK واستخرج app-debug.apk.
