
const KEY='ps_manager_v1';
const today=()=>new Date().toLocaleDateString('en-CA');
const defaultState=()=>({settings:{shopName:'محل العرض',rate:1000,half:6,sound:'yes'},devices:Array.from({length:6},(_,i)=>({id:i+1,name:'بلايستيشن '+(i+1),match:i===0,session:null,queue:[]})),records:[],nextId:7});
let state=load(),alerted=new Set(),audioCtx=null;
if(state.settings && state.settings.shopName==='محل البلايستيشن'){state.settings.shopName='محل العرض';try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
function normalizeDigits(value){return String(value??'').replace(/[٠-٩۰-۹]/g,ch=>String(ch.charCodeAt(0)>=0x06f0&&ch.charCodeAt(0)<=0x06f9?ch.charCodeAt(0)-0x06f0:ch.charCodeAt(0)-0x0660)).replace(/[٫٬]/g,'.').replace(/،/g,'.').trim()}
document.addEventListener('input',function(e){const el=e.target;if(el&&el.matches('input[data-numeric="true"]')){const pos=el.selectionStart;const old=el.value;const next=normalizeDigits(old);if(next!==old){el.value=next;try{el.setSelectionRange(pos,pos)}catch(err){}}}});
function load(){try{return JSON.parse(localStorage.getItem(KEY))||defaultState()}catch(e){return defaultState()}}
function save(){localStorage.setItem(KEY,JSON.stringify(state));}
function money(n){return Number(n||0).toLocaleString('en-US')+' ر.ي';}
function fmt(ms){let s=Math.max(0,Math.ceil(ms/1000)),m=Math.floor(s/60),r=s%60;return String(m).padStart(2,'0')+':'+String(r).padStart(2,'0')}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function currentDateRecords(){return state.records.filter(r=>r.date===today())}
function incomeFor(date){return state.records.filter(r=>r.date===date).reduce((s,r)=>s+Number(r.amount||0),0)}
function updateStats(){document.getElementById('todayIncome').textContent=money(incomeFor(today()));document.getElementById('busyCount').textContent=state.devices.filter(d=>d.session).length;document.getElementById('freeCount').textContent=state.devices.filter(d=>!d.session).length;document.getElementById('sessionsCount').textContent=currentDateRecords().length}
function renderDevices(){
 const root=document.getElementById('devices');
 if(!state.devices.length){root.innerHTML='<div class="panel empty">لا توجد أجهزة. اضغط «إضافة جهاز» للبدء.</div>';return}
 root.innerHTML=state.devices.map(d=>{
  const s=d.session,remain=s?(s.endAt-Date.now()):0,expired=s&&remain<=0,match=s&&s.type==='match';
  const status=!s?'متاح':expired?'انتهى الوقت':match?(s.half===1?'الشوط الأول':'الشوط الثاني'):'مشغول';
  return `<article class="device ${expired?'expired':''}" id="dev-${d.id}">
  <div class="devhead"><h3>${esc(d.name)}</h3><span class="badge ${s?'busy':'free'}">${status}</span></div>
  <div class="timer" data-timer="${d.id}">${s?fmt(remain):'00:00'}</div>
  <div class="sub">${s?(match?`مباراة • الشوط ${s.half} من 2 • ${s.half===1?'يتبقى للشوط الأول':'يتبقى للشوط الثاني'}`:'وقت الجلسة المتبقي'):'الجهاز جاهز لاستقبال عميل'}</div>
  <div class="who">${s?'👤 '+esc(s.customer||'عميل بدون اسم')+(s.type==='match'?' • مباراة':''):''}</div>
  <div class="actions">${!s?`<button class="good" onclick="startSession(${d.id},'normal')">بدء جلسة</button><button class="primary" onclick="startSession(${d.id},'match')">بدء مباراة</button>`:`<button class="warn" onclick="finishSession(${d.id},'manual')">إنهاء وتسجيل</button><button onclick="addTime(${d.id},5)">+٥ دقائق</button><button onclick="addTime(${d.id},10)">+١٠ دقائق</button><button onclick="silenceDevice(${d.id})">إسكات</button>`}
  <button onclick="toggleMatch(${d.id})">${d.match?'إلغاء وضع المباريات':'تفعيل وضع المباريات'}</button><button class="danger" onclick="renameDevice(${d.id})">تعديل الاسم</button><button class="danger" onclick="removeDevice(${d.id})">حذف الجهاز</button></div>
  <div class="queue"><div class="queue-title">قائمة الانتظار (${d.queue.length})</div>
  ${d.queue.map((q,i)=>`<div class="queue-item"><span>${i+1}. ${esc(q)}</span><button onclick="removeQueue(${d.id},${i})">حذف</button></div>`).join('')||'<div class="note">لا يوجد عملاء في الانتظار</div>'}
  <div class="inlineform"><input id="q-${d.id}" placeholder="اسم العميل المنتظر" maxlength="60"><button onclick="addQueue(${d.id})">＋ انتظار</button></div></div></article>`;
 }).join('');
 updateStats();
}
function startSession(id,type){
 const d=state.devices.find(x=>x.id===id);if(!d||d.session)return;
 const customer=prompt('اسم العميل (يمكن تركه فارغاً):','');if(customer===null)return;
 let mins;
 if(type==='match') mins=Number(state.settings.half)||6;
 else {const v=prompt('مدة الجلسة بالدقائق (تقبل الأرقام العربية والإنجليزية):', '30');if(v===null)return;const text=normalizeDigits(v);if(!/^[0-9]+(?:\.[0-9]+)?$/.test(text)){alert('أدخل مدة صحيحة، مثل ٣٠ أو 30.');return}mins=Number(text);if(!Number.isFinite(mins)||mins<=0){alert('أدخل مدة صحيحة أكبر من صفر.');return}}
 const startAt=Date.now();d.session={customer:customer.trim()||'عميل بدون اسم',type,startedAt:startAt,endAt:startAt+mins*60000,initialMinutes:mins,half:1,firstHalfMinutes:mins,priceRate:Number(state.settings.rate)||0};
 alerted.delete(id);save();renderDevices();
}
function finishSession(id,reason='manual'){
 const d=state.devices.find(x=>x.id===id);if(!d||!d.session)return;
 const s=d.session;let mins=Math.max(1,Math.ceil((Date.now()-s.startedAt)/60000));
 const suggested=Math.round(mins*(s.priceRate||0)/60);
 const amt=prompt('المبلغ المستحق للجلسة (تقبل الأرقام العربية والإنجليزية):',String(suggested));if(amt===null)return;
 const amount=Number(normalizeDigits(amt));if(!Number.isFinite(amount)||amount<0){alert('أدخل مبلغاً صحيحاً.');return}
 state.records.push({date:today(),time:new Date().toLocaleTimeString('ar', {hour:'2-digit',minute:'2-digit'}),device:d.name,customer:s.customer,type:s.type==='match'?'مباراة':'جلسة عادية',minutes:mins,amount,reason});
 d.session=null;alerted.delete(id);
 if(d.queue.length){const next=d.queue.shift();save();renderDevices();const start=confirm('انتهت الجلسة. هل تريد بدء جلسة للعميل التالي: '+next+'؟');if(start){const dur=prompt('مدة الجلسة بالدقائق (تقبل الأرقام العربية والإنجليزية):','30');const duration=normalizeDigits(dur);if(dur!==null&&Number(duration)>0){const now=Date.now();d.session={customer:next,type:'normal',startedAt:now,endAt:now+Number(duration)*60000,initialMinutes:Number(duration),half:1,priceRate:Number(state.settings.rate)||0};}}}
 save();renderDevices();renderReports();
}
function addTime(id,mins){const d=state.devices.find(x=>x.id===id);if(!d?.session)return;d.session.endAt=Math.max(Date.now(),d.session.endAt)+mins*60000;alerted.delete(id);save();renderDevices()}
function addQueue(id){const d=state.devices.find(x=>x.id===id);const el=document.getElementById('q-'+id),v=el.value.trim();if(!v)return;d.queue.push(v);save();renderDevices()}
function removeQueue(id,i){const d=state.devices.find(x=>x.id===id);d.queue.splice(i,1);save();renderDevices()}
function toggleMatch(id){const d=state.devices.find(x=>x.id===id);d.match=!d.match;save();renderDevices()}
function renameDevice(id){const d=state.devices.find(x=>x.id===id),v=prompt('اسم الجهاز الجديد:',d.name);if(v&&v.trim()){d.name=v.trim();save();renderDevices()}}
function removeDevice(id){const d=state.devices.find(x=>x.id===id);if(!d)return;if(!confirm('حذف '+d.name+'؟ سيتم فقد قائمة انتظاره والجلسة الحالية.'))return;state.devices=state.devices.filter(x=>x.id!==id);save();renderDevices()}
function openAddDevice(){const name=prompt('اسم الجهاز الجديد:','بلايستيشن '+state.nextId);if(!name||!name.trim())return;state.devices.push({id:state.nextId++,name:name.trim(),match:false,session:null,queue:[]});save();renderDevices()}
let alarmTimer=null;
function beep(){if(state.settings.sound==='no')return;try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();[0,0.28,0.56].forEach(t=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='square';o.connect(g);g.connect(audioCtx.destination);o.frequency.value=1100;g.gain.setValueAtTime(.55,audioCtx.currentTime+t);g.gain.setValueAtTime(.55,audioCtx.currentTime+t+.16);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+t+.24);o.start(audioCtx.currentTime+t);o.stop(audioCtx.currentTime+t+.25)});if(navigator.vibrate)navigator.vibrate([500,180,500,180,700])}catch(e){}}
function startAlarm(){if(alarmTimer!==null)return;beep();alarmTimer=setInterval(beep,1800)}
function stopAlarm(){if(alarmTimer!==null){clearInterval(alarmTimer);alarmTimer=null}if(navigator.vibrate)navigator.vibrate(0)}
function testSound(){beep();const b=document.getElementById('alertbar');b.textContent='🔔 هذا تنبيه تجريبي للصوت والواجهة.';b.classList.add('show');setTimeout(()=>{b.classList.remove('show');b.textContent='⏰ انتهى الوقت! راجع الأجهزة المنتهية.'},2500)}
function silenceDevice(id){stopAlarm();alerted.delete(id);const d=state.devices.find(x=>x.id===id);if(d?.session&&d.session.endAt<Date.now())d.session.endAt=Date.now()+1000;document.getElementById('alertbar').classList.remove('show')}
function silenceAll(){stopAlarm();alerted.clear();document.getElementById('alertbar').classList.remove('show')}
function tick(){
 let changed=false,expiredNames=[];
 state.devices.forEach(d=>{if(!d.session)return;let s=d.session,remain=s.endAt-Date.now();
  if(remain<=0&&s.type==='match'&&s.half===1){s.half=2;s.endAt=Date.now()+(Number(state.settings.half)||6)*60000;alerted.delete(d.id);beep();changed=true}
  else if(remain<=0&&!alerted.has(d.id)){alerted.add(d.id);expiredNames.push(d.name);startAlarm()}
  const el=document.querySelector(`[data-timer="${d.id}"]`);if(el)el.textContent=fmt(s.endAt-Date.now());
  const card=document.getElementById('dev-'+d.id);if(card)card.classList.toggle('expired',s.endAt<=Date.now());
 });
 if(expiredNames.length){const b=document.getElementById('alertbar');b.textContent='⏰ انتهى الوقت: '+expiredNames.join('، ')+'. اضغط إنهاء وتسجيل أو أضف وقتاً.';b.classList.add('show')}
 if(changed)save();updateStats();
}
function saveSettings(){state.settings.shopName=document.getElementById('shopName').value.trim()||'محل العرض';state.settings.rate=Math.max(0,Number(normalizeDigits(document.getElementById('hourRate').value))||0);state.settings.half=Math.max(1,Number(normalizeDigits(document.getElementById('halfLength').value))||6);state.settings.sound=document.getElementById('soundOn').value;save();alert('تم حفظ الإعدادات');renderDevices()}
function renderSettings(){document.getElementById('shopName').value=state.settings.shopName||'محل العرض';document.getElementById('hourRate').value=state.settings.rate;document.getElementById('halfLength').value=state.settings.half;document.getElementById('soundOn').value=state.settings.sound}
function renderReports(){const date=document.getElementById('reportDate').value||today();const rs=state.records.filter(r=>r.date===date);document.getElementById('reportTotal').value=money(rs.reduce((a,r)=>a+Number(r.amount||0),0));document.getElementById('reportCount').value=rs.length;document.getElementById('records').innerHTML=rs.length?rs.slice().reverse().map(r=>`<tr><td>${esc(r.time)}</td><td>${esc(r.device)}</td><td>${esc(r.customer)}</td><td>${esc(r.type)}</td><td>${r.minutes} دقيقة</td><td>${money(r.amount)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">لا توجد سجلات لهذا التاريخ.</td></tr>';updateStats()}
function exportCSV(){const date=document.getElementById('reportDate').value||today(),rs=state.records.filter(r=>r.date===date);const rows=[['التاريخ','الوقت','الجهاز','العميل','النوع','المدة بالدقائق','المبلغ'],...rs.map(r=>[r.date,r.time,r.device,r.customer,r.type,r.minutes,r.amount])];const csv='\\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\\r\\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download='تقرير-البلايستيشن-'+date+'.csv';a.click();URL.revokeObjectURL(a.href)}
function clearTodayConfirm(){const date=document.getElementById('reportDate').value||today();if(!confirm('هل تريد حذف جميع سجلات يوم '+date+'؟ لا يمكن التراجع.'))return;state.records=state.records.filter(r=>r.date!==date);save();renderReports()}
function downloadBackup(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}));a.download='نسخة-احتياطية-البلايستيشن.json';a.click();URL.revokeObjectURL(a.href)}
function restoreBackupFile(input){const file=input.files&&input.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const imported=JSON.parse(String(reader.result||''));if(!imported||typeof imported!=='object'||!imported.settings||!Array.isArray(imported.devices)||!Array.isArray(imported.records)){throw new Error('invalid')}if(!confirm('سيتم استبدال بيانات البرنامج الحالية بالنسخة الاحتياطية المحددة. هل تريد المتابعة؟')){input.value='';return}state={settings:{shopName:String(imported.settings.shopName||'محل العرض'),rate:Math.max(0,Number(imported.settings.rate)||0),half:Math.max(1,Number(imported.settings.half)||6),sound:imported.settings.sound==='no'?'no':'yes'},devices:imported.devices,nextId:Math.max(Number(imported.nextId)||1,1),records:imported.records};save();alert('تمت استعادة النسخة الاحتياطية بنجاح.');renderSettings();renderDevices();renderReports();input.value=''}catch(e){alert('تعذر استعادة الملف. تأكد أنه ملف JSON احتياطي صادر من برنامج محل العرض.');input.value=''}};reader.onerror=()=>{alert('تعذر قراءة الملف.');input.value=''};reader.readAsText(file)}
function resetApp(){if(!confirm('سيتم حذف جميع بيانات البرنامج من هذا المتصفح. هل أنت متأكد؟'))return;state=defaultState();save();renderSettings();renderDevices();renderReports()}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));['dashboard','reports','settings'].forEach(id=>document.getElementById(id).classList.toggle('hidden',id!==b.dataset.tab));if(b.dataset.tab==='reports'){document.getElementById('reportDate').value=today();renderReports()}if(b.dataset.tab==='settings')renderSettings()}));
renderSettings();renderDevices();document.getElementById('reportDate').value=today();renderReports();setInterval(tick,250);
