package com.psshop.standalone;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "psshop_game_alarm";
    private static final String ACTION_FIRE = "com.psshop.standalone.ALARM_FIRE";
    private static final String ACTION_STOP = "com.psshop.standalone.ALARM_STOP";
    private static final String EXTRA_KEY = "alarm_key";
    private static final String EXTRA_TITLE = "alarm_title";
    private static final String EXTRA_BODY = "alarm_body";

    static int notificationId(String key) { return 7000 + (key == null ? 0 : (key.hashCode() & 0x0fffffff)); }

    static void schedule(Context context, String key, long atMillis, String title, String body) {
        if (key == null || key.isEmpty() || atMillis <= 0) return;
        ensureChannel(context);
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_FIRE);
        intent.putExtra(EXTRA_KEY, key);
        intent.putExtra(EXTRA_TITLE, title == null ? "انتهى وقت اللعب" : title);
        intent.putExtra(EXTRA_BODY, body == null ? "انتهى الوقت المحدد. افتح محل العرض لإيقاف التنبيه." : body);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(key), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        long when = Math.max(atMillis, System.currentTimeMillis() + 1000);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else manager.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException deniedExactAlarm) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else manager.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void cancel(Context context, String key) {
        if (key == null || key.isEmpty()) return;
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_FIRE);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(key), intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) manager.cancel(pi);
            pi.cancel();
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(notificationId(key));
    }

    private static int requestCode(String key) { return key.hashCode(); }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "تنبيهات انتهاء اللعب", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("تنبيه عند انتهاء وقت أجهزة البلايستيشن والفرفيرة");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 700, 250, 700, 250, 1000});
            if (sound != null) channel.setSound(sound, attrs);
            nm.createNotificationChannel(channel);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String key = intent.getStringExtra(EXTRA_KEY);
        if (ACTION_STOP.equals(intent.getAction())) {
            if (key != null) {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(notificationId(key));
            }
            return;
        }
        if (!ACTION_FIRE.equals(intent.getAction())) return;
        ensureChannel(context);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String body = intent.getStringExtra(EXTRA_BODY);
        Intent open = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 9901, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(context, AlarmReceiver.class).setAction(ACTION_STOP).putExtra(EXTRA_KEY, key);
        PendingIntent stopPi = PendingIntent.getBroadcast(context, requestCode("stop:" + key), stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title == null ? "انتهى وقت اللعب" : title)
                .setContentText(body == null ? "افتح محل العرض لمراجعة الجهاز" : body)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setAutoCancel(true)
                .setContentIntent(content)
                .addAction(android.R.drawable.ic_media_pause, "إيقاف التنبيه", stopPi);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                    .setVibrate(new long[]{0, 700, 250, 700, 250, 1000});
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notificationId(key), builder.build());
    }
}
