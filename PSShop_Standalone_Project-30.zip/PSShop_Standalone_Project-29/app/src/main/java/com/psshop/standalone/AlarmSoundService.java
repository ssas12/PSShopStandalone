package com.psshop.standalone;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;

public class AlarmSoundService extends Service {
    static final String ACTION_START = "com.psshop.standalone.SOUND_START";
    static final String ACTION_STOP = "com.psshop.standalone.SOUND_STOP";
    private static final String CHANNEL_ID = "psshop_game_alarm_v2";
    private Ringtone ringtone;
    private Vibrator vibrator;
    private String activeKey;
    private int activeNotificationId;
    private TextToSpeech textToSpeech;
    private final Handler speechHandler = new Handler(Looper.getMainLooper());
    private String announcementText = "انتهى وقت اللعب";
    private final Runnable repeatAnnouncement = new Runnable() {
        @Override public void run() {
            try {
                if (textToSpeech != null && !announcementText.isEmpty()) {
                    textToSpeech.speak(announcementText, TextToSpeech.QUEUE_FLUSH, null, "psshop_alarm_announcement");
                }
            } catch (Exception ignored) { }
            speechHandler.postDelayed(this, 10000);
        }
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        String action = intent.getAction();
        String key = intent.getStringExtra(AlarmReceiver.EXTRA_KEY);
        if (ACTION_STOP.equals(action)) {
            if (key == null || activeKey == null || key.equals(activeKey)) stopAlarm();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) return START_NOT_STICKY;
        if (key == null) key = "game";
        if (activeKey != null && !activeKey.equals(key)) stopSoundOnly();
        activeKey = key;
        activeNotificationId = AlarmReceiver.notificationId(key);
        String title = intent.getStringExtra(AlarmReceiver.EXTRA_TITLE);
        String body = intent.getStringExtra(AlarmReceiver.EXTRA_BODY);
        announcementText = title == null ? "انتهى وقت اللعب" : title;
        ensureChannel();
        startForeground(activeNotificationId, buildNotification(key, title, body));
        startSound();
        startSpeechAnnouncement();
        return START_STICKY;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "إنذار انتهاء جلسات محل العرض", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("إنذار متكرر عند انتهاء وقت اللعب؛ أوقفه من الإشعار أو داخل البرنامج.");
                channel.setSound(null, (AudioAttributes)null); // صوت الإنذار يُشغّل هنا حتى يتكرر إلى أن يوقفه المستخدم.
                channel.enableVibration(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String key, String title, String body) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 9901, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, AlarmReceiver.class).setAction(AlarmReceiver.ACTION_STOP).putExtra(AlarmReceiver.EXTRA_KEY, key);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, key.hashCode() ^ 0x5511, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
          .setContentTitle(title == null ? "⏰ انتهى وقت اللعب" : title)
          .setContentText(body == null ? "افتح محل العرض لمراجعة الجلسة" : body)
          .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
          .setOngoing(true).setAutoCancel(false).setContentIntent(content)
          .addAction(android.R.drawable.ic_media_pause, "إيقاف التنبيه", stopPi);
        return b.build();
    }

    private void startSound() {
        try {
            stopSoundOnly();
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            ringtone = RingtoneManager.getRingtone(getApplicationContext(), sound);
            if (ringtone != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) ringtone.setLooping(true);
                ringtone.play();
            }
        } catch (Exception ignored) { }
        try {
            vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = new long[]{0, 700, 250, 700, 250, 1000};
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                else vibrator.vibrate(pattern, 0);
            }
        } catch (Exception ignored) { }
    }

    private void startSpeechAnnouncement() {
        speechHandler.removeCallbacks(repeatAnnouncement);
        try {
            if (textToSpeech != null) {
                textToSpeech.stop();
                textToSpeech.shutdown();
                textToSpeech = null;
            }
            textToSpeech = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                    int languageStatus = textToSpeech.setLanguage(new Locale("ar"));
                    if (languageStatus != TextToSpeech.LANG_MISSING_DATA
                            && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED) {
                        textToSpeech.setSpeechRate(0.9f);
                        textToSpeech.speak(announcementText, TextToSpeech.QUEUE_FLUSH, null, "psshop_alarm_first");
                        speechHandler.postDelayed(repeatAnnouncement, 10000);
                    }
                }
            });
        } catch (Exception ignored) { }
    }

    private void stopSoundOnly() {
        speechHandler.removeCallbacks(repeatAnnouncement);
        try { if (textToSpeech != null) textToSpeech.stop(); } catch (Exception ignored) { }
        try { if (ringtone != null && ringtone.isPlaying()) ringtone.stop(); } catch (Exception ignored) { }
        ringtone = null;
        try { if (vibrator != null) vibrator.cancel(); } catch (Exception ignored) { }
        vibrator = null;
    }

    private void stopAlarm() {
        stopSoundOnly();
        NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && activeNotificationId != 0) nm.cancel(activeNotificationId);
        activeKey = null;
        activeNotificationId = 0;
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        stopSoundOnly();
        try { if (textToSpeech != null) textToSpeech.shutdown(); } catch (Exception ignored) { }
        textToSpeech = null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
