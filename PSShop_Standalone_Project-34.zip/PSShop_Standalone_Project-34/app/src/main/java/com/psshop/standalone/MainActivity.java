package com.psshop.standalone;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int SAVE_BACKUP_REQUEST = 1002;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson = "";
    private WebView appWebView;
    private static final int VOICE_REQUEST = 1003;
    private static final int AUDIO_PERMISSION_REQUEST = 2002;
    private boolean voicePermissionPending = false;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        WebView w = new WebView(this);
        appWebView = w;
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void scheduleAlarm(String key, long atMillis, String title, String body) {
                AlarmReceiver.schedule(MainActivity.this, key, atMillis, title, body);
            }
            @JavascriptInterface
            public void cancelAlarm(String key) {
                AlarmReceiver.cancel(MainActivity.this, key);
            }
            @JavascriptInterface
            public void stopAlarmSound(String key) {
                runOnUiThread(() -> {
                    Intent stop = new Intent(MainActivity.this, AlarmSoundService.class)
                            .setAction(AlarmSoundService.ACTION_STOP);
                    if (key != null && !key.trim().isEmpty()) {
                        stop.putExtra(AlarmReceiver.EXTRA_KEY, key.trim());
                    }
                    try { MainActivity.this.startService(stop); } catch (Exception ignored) { }
                });
            }
            @JavascriptInterface
            public void startVoiceRecognition() {
                runOnUiThread(() -> beginVoiceRecognition());
            }
            @JavascriptInterface
            public void saveBackup(String json, String filename) {
                runOnUiThread(() -> {
                    pendingBackupJson = json == null ? "{}" : json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "backup.json" : filename);
                    startActivityForResult(intent, SAVE_BACKUP_REQUEST);
                });
            }
        }, "AndroidBridge");
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(Intent.createChooser(intent, "اختر النسخة الاحتياطية"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        w.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2001);
        }
        // Prompt once to exempt the app from Android battery optimization.
        // This is important on Xiaomi/MIUI phones that may suspend background alarms.
        requestBatteryExemptionIfNeeded();
    }


    private void beginVoiceRecognition() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voicePermissionPending = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST);
            return;
        }
        launchVoiceRecognition();
    }

    private void launchVoiceRecognition() {
        try {
            Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
            intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
            intent.putExtra("android.speech.extra.LANGUAGE", "ar");
            intent.putExtra("android.speech.extra.LANGUAGE_PREFERENCE", "ar");
            intent.putExtra("android.speech.extra.PROMPT", "قل أمر الجهاز والمدة");
            intent.putExtra("android.speech.extra.MAX_RESULTS", 3);
            startActivityForResult(intent, VOICE_REQUEST);
        } catch (Exception e) {
            sendVoiceResult("");
            Toast.makeText(this, "خدمة التعرف على الصوت غير متاحة. تحقق من وجود خدمة Google للصوت.", Toast.LENGTH_LONG).show();
        }
    }

    private void sendVoiceResult(String text) {
        if (appWebView == null) return;
        String safe = org.json.JSONObject.quote(text == null ? "" : text);
        runOnUiThread(() -> appWebView.evaluateJavascript("window.onNativeVoiceResult && window.onNativeVoiceResult(" + safe + ")", null));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && voicePermissionPending) launchVoiceRecognition();
            else sendVoiceResult("");
            voicePermissionPending = false;
        }
    }

    private void requestBatteryExemptionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;

        android.content.SharedPreferences prefs = getSharedPreferences("psshop_runtime_setup", MODE_PRIVATE);
        if (prefs.getBoolean("battery_prompt_shown", false)) return;
        prefs.edit().putBoolean("battery_prompt_shown", true).apply();

        new AlertDialog.Builder(this)
                .setTitle("مهم لعمل منبه محل العرض")
                .setMessage("حتى يعمل منبه انتهاء الجلسة عند تصغير البرنامج أو قفل الشاشة، اسمح لمحل العرض بالعمل دون قيود البطارية. في بعض هواتف شاومي قد تحتاج أيضًا إلى تفعيل التشغيل التلقائي من إعدادات التطبيق.")
                .setCancelable(false)
                .setPositiveButton("ضبط الآن", (dialog, which) -> {
                    try {
                        Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        try {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("لاحقًا", (dialog, which) -> {
                    try {
                        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        // Do not force-open settings after choosing later.
                    } catch (Exception ignored) { }
                })
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST) {
            String spoken = "";
            if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<String> matches = data.getStringArrayListExtra("android.speech.extra.RESULTS");
                if (matches != null && !matches.isEmpty()) spoken = matches.get(0);
            }
            sendVoiceResult(spoken);
        } else if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        } else if (requestCode == SAVE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = "";
        }
    }
}
