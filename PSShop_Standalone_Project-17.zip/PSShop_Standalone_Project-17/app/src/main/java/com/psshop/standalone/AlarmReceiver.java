package com.psshop.standalone;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    static final String ACTION_FIRE = "com.psshop.standalone.ALARM_FIRE";
    static final String ACTION_STOP = "com.psshop.standalone.ALARM_STOP";
    static final String EXTRA_KEY = "alarm_key";
    static final String EXTRA_TITLE = "alarm_title";
    static final String EXTRA_BODY = "alarm_body";

    static int notificationId(String key) { return 7000 + (key == null ? 0 : (key.hashCode() & 0x0fffffff)); }
    private static int requestCode(String key) { return key.hashCode(); }

    static void schedule(Context context, String key, long atMillis, String title, String body) {
        if (key == null || key.isEmpty() || atMillis <= 0) return;
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_FIRE);
        intent.putExtra(EXTRA_KEY, key);
        intent.putExtra(EXTRA_TITLE, title == null ? "انتهى وقت اللعب" : title);
        intent.putExtra(EXTRA_BODY, body == null ? "انتهى الوقت المحدد. افتح محل العرض لمراجعة الجلسة." : body);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(key), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        long when = Math.max(atMillis, System.currentTimeMillis() + 1000);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else manager.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException deniedExactAlarm) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else manager.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void cancel(Context context, String key) {
        if (key == null || key.isEmpty()) return;
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_FIRE);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(key), intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) manager.cancel(pi);
            pi.cancel();
        }
        Intent stop = new Intent(context, AlarmSoundService.class).setAction(AlarmSoundService.ACTION_STOP);
        stop.putExtra(EXTRA_KEY, key);
        context.startService(stop);
    }

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String key = intent.getStringExtra(EXTRA_KEY);
        if (ACTION_STOP.equals(intent.getAction())) {
            Intent stop = new Intent(context, AlarmSoundService.class).setAction(AlarmSoundService.ACTION_STOP);
            stop.putExtra(EXTRA_KEY, key);
            context.startService(stop);
            return;
        }
        if (!ACTION_FIRE.equals(intent.getAction())) return;
        Intent service = new Intent(context, AlarmSoundService.class).setAction(AlarmSoundService.ACTION_START);
        service.putExtra(EXTRA_KEY, key);
        service.putExtra(EXTRA_TITLE, intent.getStringExtra(EXTRA_TITLE));
        service.putExtra(EXTRA_BODY, intent.getStringExtra(EXTRA_BODY));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
        else context.startService(service);
    }
}
